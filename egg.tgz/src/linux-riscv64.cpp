// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("linux riscv64"); }
int main(){
  announce();
  return lionss_run_workload("linux-riscv64");
}
