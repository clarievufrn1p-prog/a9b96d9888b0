// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("link checker"); }
int main(){
  announce();
  return lionss_run_workload("link-checker");
}
