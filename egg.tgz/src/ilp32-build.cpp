// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("ilp32 build"); }
int main(){
  announce();
  return lionss_run_workload("ilp32-build");
}
