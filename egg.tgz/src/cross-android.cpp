// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("cross android\n", stdout);
  return lionss_run_workload("cross-android");
}
