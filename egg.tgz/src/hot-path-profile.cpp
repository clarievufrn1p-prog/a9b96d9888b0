// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("hot path profile\n", stdout);
  return lionss_run_workload("hot-path-profile");
}
